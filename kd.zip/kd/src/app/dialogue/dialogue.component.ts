import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { RouterModule, Router }  from '@angular/router'; 

@Component({
  selector: 'app-dialogue',
  templateUrl: './dialogue.component.html',
  styleUrls: ['./dialogue.component.css']
})
export class DialogueComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit() {
  }
  close():void{
      this._router.navigate(['/signin']); 
  }
  confirm(){
    alert("Thank You");
    this._router.navigate(['']);
  }
}
