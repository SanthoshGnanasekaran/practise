import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ConfirmModComponent } from './confirm-mod/confirm-mod.component';
import { SigninComponent } from './signin/signin.component';
import { DialogueComponent } from './dialogue/dialogue.component';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';
import { HttpClientModule } from '@angular/common/http';
import{StateService} from './state.service';
import { NavbarComponent } from './navbar/navbar.component';

const appRoutes: Routes = [   
   { path: 'signin', component: SigninComponent },
   { path: '', component: ConfirmModComponent },
   {path:'dialogue',component:DialogueComponent}
  
];


@NgModule({
 
  declarations: [
    AppComponent,
    ConfirmModComponent,
    SigninComponent,
    DialogueComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
     RouterModule.forRoot(appRoutes),
     BootstrapModalModule,
     HttpClientModule
  ],
  providers: [StateService],
  bootstrap: [AppComponent],
  exports: [ RouterModule ]
})
export class AppModule { }
