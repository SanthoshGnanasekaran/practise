import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { StateService } from '../state.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private fb: FormBuilder, private _router: Router, private http: HttpClient, private stateservice:StateService) {
    this.createForm();
  }
  public State: string

  ngOnInit() {
   
 }
  private details;
  savedValue;
  hideform: boolean = true;
  showtable: boolean = false;
  public createForm() {
    this.details = this.fb.group({
      name: '',
      email: '',
      address: '',
      address2: '',
      city: '',
      state: '',
      zip: ''
      // gender:''
    });
  }

  public saveForm() {
    this.postservice();
    this.hideform = !this.hideform;
    this.showtable = !this.showtable;
    console.log(this.details.value);
  }

  public onBack(): void {
    this._router.navigate(['/dialogue']);
    // alert("hi")
  }

  public getService() {
    this.http.get('http://localhost:3000/user').subscribe(data => {
      this.savedValue = data;
      console.log(this.savedValue);
    }

    )
  }
  postservice() {
    this.http.post('http://localhost:3000/user', this.details.value).subscribe(data => {
      console.log(data);
      this.getService();
    }

    )
      }
  
  

  states = [{"statename": "TamilNadu"}, {"statename": "Kerala"}, {"statename": "Karnatake"}];
  selectedState = this.states[1];
  onChange(state) { 
    console.log(state)
 }
}
