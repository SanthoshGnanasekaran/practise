import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-mod',
  templateUrl: './confirm-mod.component.html',
  styleUrls: ['./confirm-mod.component.css']
  
})
export class ConfirmModComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
 
}
