import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmModComponent } from './confirm-mod.component';

describe('ConfirmModComponent', () => {
  let component: ConfirmModComponent;
  let fixture: ComponentFixture<ConfirmModComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmModComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmModComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
